const fs = require('fs');
const path = require('path');
console.log(__dirname);
console.log(typeof __dirname);
const parent = path.normalize(__dirname+'/..');
const fullPath = path.join(parent, '/files/x.txt');
fs.readFile(fullPath
,(err, buffer)=>{
    if(err){
        console.log('File Read Error', err);
    }
    else{
        console.log(buffer.toString());
    }
});