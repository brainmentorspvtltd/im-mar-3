const bigFilePath ='/Users/amit/Documents/softwares/Xcode_11.5.xip';
const bigFilePath2 ='/Users/amit/Documents/softwares/XcodeCOPY_11.5.xip';
const fs = require('fs');
const chalk = require('chalk');
// fs.readFile(bigFilePath, (err, buffer)=>{
//     if(err){
//         console.log('Error is ',err);
//     }
//     else{
//         console.log('Buffer ',buffer);
//     }

// })
//const readStream = fs.createReadStream(bigFilePath, {highWaterMark:10});
const readStream = fs.createReadStream(bigFilePath);
const writeStream = fs.createWriteStream(bigFilePath2);
readStream.on('open',(err)=>{

        console.log(chalk.green('Stream Open'));

});
//readStream.pipe(writeStream);
readStream.on('data',(chunk)=>{
    //writeStream.write(chunk);
    //console.log(chalk.blueBright('Chunk is ',chunk));
});
readStream.on('err',(err)=>{
    console.log(chalk.red('Stream Error ',err));
});
readStream.on('end',()=>{
    console.log(chalk.green.bold.underline('COPY Done'));
});
readStream.on('close',()=>{
    console.log(chalk.bgMagenta.bold.italic.underline('Stream close'));
});

console.log('BIG FILE CODE ENDS');