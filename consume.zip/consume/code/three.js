const fs = require('fs');
const filePath ='/Users/amit/Documents/im-mar-end-batch/consume/files/y.txt';
console.log('Watching...');
const chokidar = require('chokidar');
chokidar.watch('.').on('all', (event,path)=>{
    console.log('Event ',event);
    console.log('Path ',path);
})
// fs.watchFile(filePath,(curr, prev)=>{
//     if(curr!=prev){
//         const data = fs.readFileSync(filePath);
//         console.log(data.toString());
//     }
// })