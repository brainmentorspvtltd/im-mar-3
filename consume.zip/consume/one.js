const fs = require('fs');
const path = require('path');
console.log('Before Read');

// try{
// const buffer = fs.readFileSync(__filename);
// console.log(buffer);
// }
// catch(err){
//     console.log(err);
// }
//fs.readFile('/Users/amit/Documents/im-mar-end-batch/consume/one.js'
const fullPath = path.join(__dirname, '/files/x.txt');
fs.readFile(fullPath
,(err, buffer)=>{
    if(err){
        console.log('File Read Error', err);
    }
    else{
        console.log(buffer.toString());
    }
});
console.log("After Read");

fs.writeFile(path.join(__dirname, '/files','/y.txt'),
 'I am Writing Data in FILE....', (err)=>{
     if(err){
         console.log("Error During File Write ",err);
     }
     else{
         console.log('File Write Done...');
     }
 });
 //fs.appendFile();
 //fs.unlink(); // file delete
 //fs.copyFile();
 //fs.mkdir