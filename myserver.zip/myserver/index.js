//const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const fileOperations = require('./utils/fileserve');
const certOptions = {
    key: fs.readFileSync(path.join(__dirname,'/cert/privatekey.key')),
    cert: fs.readFileSync(path.join(__dirname,'/cert/certificate.pem'))
};
const server = https.createServer(certOptions, (request, response)=>{
    const url = request.url=='/'?'/index.html':request.url;
    console.log('URL ', url);
    if(fileOperations.isStaticFile(url)){
        fileOperations.serveFile(response, url);
    }

    // response.write('Hello I am Https Server');
    // response.end();
});
server.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log('Server Start Error ',err);
    }
    else{
        console.log('Server Started... ', server.address().port);
    }
})