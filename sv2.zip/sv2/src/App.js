import React from 'react';
import Search from './containers/Search';


const App= (props)=> {


    return (
        <>
            <Search/>
        </>
    )
}
export default App;
