import React from 'react'

export const TotalItems=({total})=> {


    return (
        <>
            <p>Total Items are {total}</p>
        </>
    )
}
