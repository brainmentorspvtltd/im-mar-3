import React from 'react'
import { Item } from './Item'

export const List=(props)=> {

    //const jsx = props.products.map(product=>(<Item key={product.id} product = {product}/>));
    //console.log('JSX is ',jsx);
    return (
        <>
            <p>List of Records</p>
            {props.products.map(product=>(<Item key={product.id} product = {product}/>))}

        </>
    )
}
