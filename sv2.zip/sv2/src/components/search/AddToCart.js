import React from 'react'

export const AddtoCart=(props)=> {


    return (
        <>
            <button className = 'btn btn-success'>Add To Cart</button>
            <br/>
        </>
    )
}
