import React from 'react';
export const ViewItemsInCart = (props)=>{
    return (<div className = 'text-end'>Items in Cart {props.total}</div>)
}