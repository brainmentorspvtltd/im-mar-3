import React from 'react'

export const Title=(props)=> {


    return (
        <>
            <h2 className = 'alert-info text-center'>Shop App</h2>
        </>
    )
}
