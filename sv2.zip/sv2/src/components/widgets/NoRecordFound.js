import React from 'react'

export const NoRecordFound= (props)=> {


    return (
        <>
            <h1>No Item Found .....</h1>
        </>
    )
}
