import React, { Component } from 'react'
import { Input } from '../components/search/Input';
import { List } from '../components/search/List';
import { TotalItems } from '../components/search/TotalItems';
import { Total } from '../components/search/Total';
import { Title } from '../components/widgets/Title';
import { getProducts } from '../utils/ajax';
import { ViewItemsInCart } from '../components/search/ViewItemsInCart';

export default class Search extends Component {
    constructor(props) {
        super(props);

        this.state = {
            products:[]
        };
        console.log("1. Constructor Call");


    }

    UNSAFE_componentWillMount(){
        console.log("2. ComponentWillMount Call");
    }

    render() {
        console.log("3. Render Call");
        return (
            <div className = 'container'>
                <Title/>
                <ViewItemsInCart/>
                <Input/>
                <TotalItems total = {this.state.products.length}/>
                <List products = {this.state.products}/>
                <Total/>
            </div>
        )
    }

    componentDidMount(){
        console.log("4. ComponentDidMount Call ");
        const promise = getProducts();
        promise.then(response=>{
            //console.log(response.data.products);
            this.setState({products:response.data.mobiles});
        }).catch(err=>{
            console.log('Error is ',err);
        })
        // promise.then(response=>{
        //     response.json().then(data=>{
        //         console.log('Data Rec ',data);
        //         this.setState({products:data.products});
        //     }).catch(err=>{
        //         console.log('Invalid JSON ',err);
        //     })
        // }).catch(err=>{
        //     console.log('Response Error ',err);
        // })
    }



}
