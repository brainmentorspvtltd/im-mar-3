import React from 'react';
export const Footer = ()=>{
    return (<h1>I am a Footer</h1>);
}