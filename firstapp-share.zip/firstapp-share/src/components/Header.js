import React from 'react';
export const Header = ()=>{
    return (<h1>I am a Header</h1>);
}