// First Component (Root Component)
import React, {Component} from 'react';
import './App.css';
import { Footer } from './components/Footer';
import { Header } from './components/Header'; // Destructure
// Smart Component (Presentation + Events + Life Cycle + State + Props + Logic)
class App extends Component{
    constructor(){
        super();
        this.likes = 0;
        this.state = {likeValue:0};
        console.log("1. Constructor Call ",this);
    }
    likePlus(){
       // console.log('This is ',this);
       this.likes++;
    //    let l = this.state.likeValue;
    //    l++;
       console.log('Like is ',this.likes);
       this.setState({likeValue:this.likes}); // Immutable Style // render call
        //this.render();
    }
    render(){
        console.log("2. Render call");
        let message = 'Hello React JS - 2021';
        // inline
        const style = {color:'red', backgroundColor:'yellow'};
        var myValue = 1;
        const products = [
            {id:1001, name:'Apple', price:99999},
            {id:1002, name:'Nokia', price:9999},
            {id:1003, name:'Samsung', price:49999},
            {id:1004, name:'MI', price:5999}
        ];
        return (<div style={style}>
            {myValue===1?<Header/>:<Footer/>}
            <p>Products</p>
            {products.map(product=><div key={product.id}><p>{product.name} {product.price}</p></div>)}
            <p>{message}</p>
            <p className='green'> Hi React JS</p>
            <p style = {{backgroundColor:'green', color:'white', fontSize:'40px'}}>Total Likes {this.state.likeValue} </p>
            <button onClick={this.likePlus.bind(this)}>Like</button>
        </div>)
    }
}

export default App;


// Dumb Component (Presentation)
//function App(){

/*
const App = ()=>{
    let message = 'Hello React JS - 2021';
    // inline
    const style = {color:'red', backgroundColor:'yellow'};
    var myValue = 1;
    const products = [
        {id:1001, name:'Apple', price:99999},
        {id:1002, name:'Nokia', price:9999},
        {id:1003, name:'Samsung', price:49999},
        {id:1004, name:'MI', price:5999}
    ];
   // return React.createElement('h1',null,'Hello React JS'); // <h1>Hello ReactJS </h1>
    //return React.createElement('h1',{style},'Hello React JS' );
    /*return React.createElement('div', null,
     React.createElement('p',null,'Hello React JS'),
     React.createElement('p',null,'Hi React JS'))
     */
    /*
    return (<div style={style}>
        {myValue==1?<Header/>:<Footer/>}
        <p>Products</p>
        {products.map(product=><div><p>{product.name} {product.price}</p></div>)}
        <p>{message}</p>
        <p className='green'> Hi React JS</p>

    </div>)
}
export default App;
*/