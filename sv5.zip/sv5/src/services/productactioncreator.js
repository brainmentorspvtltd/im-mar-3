export const productActionCreator = (name, price, desc, url, type)=>{
    const product = {
        name, price, desc, url
    };
    const action = {
        payload: product,
        type : type
    };
    return action;

}