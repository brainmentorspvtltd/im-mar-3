import React, { Component, useEffect } from 'react'

export const NoRecordFound= (props)=> {

    useEffect(()=>{
        console.log("#######I am Like Component Did Mount ");
        return ()=>{
            console.log("I am Like Component Will UnMount::::::::");
        }
    },[]);
    return (
        <>
            <h1>No Item Found .....</h1>
        </>
    )
}
/*
export class NoRecordFound extends Component{
    componentDidMount(){
        console.log('NO RecordFound Component Loaded...');
    }
    componentWillUnmount(){
        // clean up code
        console.log('No Record Found Component UnMounted....');
    }
    render(){
        return (<h1>No Item Found .....</h1>);
    }
}*/