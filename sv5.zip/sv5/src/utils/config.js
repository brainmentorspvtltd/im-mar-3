export const CONFIG = {
    //PRODUCTS_URL :'http://localhost:3000/server/products.json'
    PRODUCTS_URL:'/mobiles.json',
    ADD_PRODUCT:'ADD_PRODUCT'

}