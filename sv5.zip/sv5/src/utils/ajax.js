import {CONFIG} from './config';
import axios from 'axios';
export function loadAxiosConfig(){
    // global
   // axios.defaults.baseURL = 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master';
   console.log('ENV IS ',process.env.REACT_APP_BASE_URL);
   axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
   axios.defaults.timeout = 5000;
   let myInterceptor = axios.interceptors.request.use(requestObject=>{
       console.log('$$$$$$$$Interceptor Call...........');
    requestObject.tokenId = localStorage.tokenId;
    // cancel
   // requestObject.cancel();
    return requestObject;
   },err=>{
       console.log('Error in Request Interceptor ',err);
   });
   setTimeout(()=>{
    axios.interceptors.request.eject(myInterceptor);
    console.log('Eject Interceptor....');
   },10000);

}
export function getProducts(){
   // local setting
    // var heavy =  axios.create({
    //     baseURL:'',
    //     timeout:7000
    // });
   // heavy.get()
    const promise = axios.get(CONFIG.PRODUCTS_URL);
    //const promise = fetch(CONFIG.PRODUCTS_URL);
    return promise;
}