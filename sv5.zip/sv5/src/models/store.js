import {createStore} from 'redux';
import { productReducer } from '../services/productreducer';
export const store = createStore(productReducer);
store.subscribe(()=>{
    console.log('Store State Updated...',store.getState());
})