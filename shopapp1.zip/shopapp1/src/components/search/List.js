import React from 'react'
import { Item } from './Item'

export const List=(props)=> {


    return (
        <>
            <p>List of Records</p>
            <Item/>
        </>
    )
}
