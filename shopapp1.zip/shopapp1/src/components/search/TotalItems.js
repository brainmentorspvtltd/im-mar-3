import React from 'react'

export const TotalItems=(props)=> {


    return (
        <>
            <p>Total Items are </p>
        </>
    )
}
