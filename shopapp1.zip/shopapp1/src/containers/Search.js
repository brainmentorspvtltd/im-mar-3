import React, { Component } from 'react'
import { Input } from '../components/search/Input';
import { List } from '../components/search/List';
import { TotalItems } from '../components/search/TotalItems';
import { Total } from '../components/search/Total';
import { Title } from '../components/widgets/Title';

export default class Search extends Component {
    constructor(props) {
        super(props);

        this.state = {

        }


    }


    render() {
        return (
            <div className = 'container'>
                <Title/>
                <Input/>
                <TotalItems/>
                <List/>
                <Total/>
            </div>
        )
    }
}
