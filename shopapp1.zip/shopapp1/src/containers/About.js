import React from 'react'

export const About=(props)=> {


    return (
        <>
                <h1>I am About</h1>
        </>
    )
}
