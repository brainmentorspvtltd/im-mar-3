function printIt(playerInfo){
    document.getElementById('result').innerHTML='';
    let img = document.createElement('img'); // <img>
    img.src =playerInfo.photo;
    document.getElementById('result').appendChild(img);
    let pTag = document.createElement('p');
    pTag.innerText = `Name ${playerInfo.name} Age ${playerInfo.age} DOB ${playerInfo.born}`;
    document.getElementById('result').appendChild(pTag);
}

const hideIt = ()=>document.querySelector('#loader').style.display='none';
const showIt = ()=>document.querySelector('#loader').style.display='block';
hideIt();
function searchIt(){
    let playerId  = document.getElementById('playerid').value;
    if(playerId==-1){
        alert('Player Id Not Selected');
        return ;
    }
    showIt();
    let promise = getPlayerInfo(playerId);
    promise.then(response=>{
        //console.log('Response ',response);
        response.json().then(data=>{
            hideIt();
            const playerInfo = {born: data.born, name:data.fullName, photo:data.imageURL, age:data.currentAge}
            console.log('PlayerInfo is ',playerInfo);
            printIt(playerInfo);
        }).catch(err=>{
            console.log('Invalid JSON ',err);
        })
    }).catch(err=>{
        console.log('Error ',err);
    })
}

function getPlayerInfo(playerId){
    let url = `https://cricapi.com/api/playerStats?pid=${playerId}&apikey=A8zoDoPaQgefmB7KunnSuApSgL73`;
    const options = {method:'GET',body:JSON.stringify({x:100, y:200})};
    //const promise = fetch(url,options);
    const promise = fetch(url);
    return promise;
}

/*
function getPlayerInfo(playerId){
    var xmlHttpRequest;
    let url = `https://cricapi.com/api/playerStats?pid=${playerId}&apikey=A8zoDoPaQgefmB7KunnSuApSgL73`;
    if(window.XMLHttpRequest){
     xmlHttpRequest = new XMLHttpRequest();
    }
    else
    if(window.ActiveXObject){
        // for old browsers
        xmlHttpRequest = new ActiveXObject('Microsoft.XMLHttp');
    }
    const promise = new Promise((resolve, reject)=>{
        xmlHttpRequest.onreadystatechange = function(){
            console.log(this.readyState);
            if(this.readyState == 4 && this.status == 200){
                //console.log('Response is ',this.responseText);
                console.log('Response Type ',typeof this.responseText);
                const obj = JSON.parse(this.responseText);
                console.log(obj);
                console.log(typeof obj);
                resolve(obj);
            }
        }
        xmlHttpRequest.open('GET',url, true);
        xmlHttpRequest.send(null);
    });
    return promise;



}
*/