import React, {useState} from 'react';
import { Route, Switch } from 'react-router';
import { Header } from './components/widgets/Header';
import Search from './containers/Search';
import { ShareContext } from './models/sharecontext';
import {Home} from './containers/Home';
import {About} from './containers/About';


import { AddProduct } from './components/AddProduct';
//let total  = 0;
const App= (props)=> {
    console.log('Re Render of App');

    const [total, setTotal] = useState(0);
    const updateTotalFn = (currentValue)=>{
       // total += currentValue;
        console.log('Total is ',total);
        setTotal(total + currentValue);
    }
    let role = 'GUEST';
    let jsx = (<></>) ;
    if(role=='ADMIN'){
        jsx  = (<Route path="/adduser" render={()=>{
            return (<h1>Admin AddUser</h1>)
        }}/>);
    }
    return (
        <div className='container'>
            <ShareContext.Provider value={{totalItemsInCart: total, updateTotal: updateTotalFn}}>
            <Header name = 'Amit' city='Delhi'/>
            <Switch>
                <Route exact path="/" component={Home}/>
                <Route path="/search" component={Search}/>
                <Route path="/about/:name/:city" component={About}/>
                <Route path="/add" component={AddProduct}/>
                {jsx}
                <Route render={()=>{
                    return (<h1>OOPS U TYPE SOMETHING ELSE....</h1>)
                }}/>
            </Switch>
            </ShareContext.Provider>
        </div>
    )
}
export default App;
