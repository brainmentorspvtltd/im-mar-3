import React, { Component, useRef, useState } from "react";


export const AddProduct = (props)=>{

     let name = useRef();
    let age = useRef();
    let address = useRef();
     let phone = useRef();
    const [message, setMessage]  = useState('');
     const addProduct=()=>{

        let name1 = name.current.value;
        let age1 = age.current.value;
        let address1 = address.current.value;
        let phone1 = phone.current.value;
        let message = `Name ${name1} Age ${age1} Address ${address1} Phone ${phone1}`;
        setMessage (message);
     }

    return (
        <>
        <h2 className = 'alert-info'>Add Product</h2>
        <h3>{message}</h3>
        <div>
          <label>Name</label>
          <input ref={name} className='form-control' type="text" placeholder="Type Ur Name Here" />
        </div>
        <div>
          <label>Age</label>
          <input ref={age} className='form-control' type="text" placeholder="Type Ur Age Here" />
        </div>
        <div>
          <label>Address</label>
          <input ref={address} className='form-control' type="text" placeholder="Type Ur Address Here" />
        </div>
        <div>
          <label>Phone</label>
          <input ref={phone} className='form-control' type="text" placeholder="Type Ur Phone Here" />
        </div>
        <div>
            <button onClick={addProduct} className = 'btn btn-primary me-2'>Add Product</button>
            <button className = 'btn btn-secondary'>Clear All</button>
        </div>
      </>
    );
}

/*
export class AddProduct extends Component {
  constructor() {
    super();
    this.state = {message :''};
    this.name = '';
    this.age = '';
    //  this.name = React.createRef();
    // this.age = React.createRef();
    this.address = React.createRef();
     this.phone = React.createRef();
  }

  setName(element){
    this.name = element.value;
  }

  setAge(element){
    this.age = element.value;
  }

  addProduct(){
    let name = this.name;
    let age = this.age;
    // let name = this.name.current.value;
    // let age = this.age.current.value;
    let address = this.address.current.value;
    let phone = this.phone.current.value;


      // Old Way
    // let name = this.refs.name.value;
    // let age  =this.refs.age.value;
    // let address = this.refs.address.value;
    // let phone = this.refs.phone.value;
    let message = `Name ${name} Age ${age} Address ${address} Phone ${phone}`;
    this.setState ({message:message});
  }
  render() {
    return (
      <>
        <h2 className = 'alert-info'>Add Product</h2>
        <h3>{this.state.message}</h3>
        <div>
          <label>Name</label>
          <input ref={this.setName.bind(this)} className='form-control' type="text" placeholder="Type Ur Name Here" />
        </div>
        <div>
          <label>Age</label>
          <input ref={this.setAge.bind(this)} className='form-control' type="text" placeholder="Type Ur Age Here" />
        </div>
        <div>
          <label>Address</label>
          <input ref={this.address} className='form-control' type="text" placeholder="Type Ur Address Here" />
        </div>
        <div>
          <label>Phone</label>
          <input ref={this.phone} className='form-control' type="text" placeholder="Type Ur Phone Here" />
        </div>
        <div>
            <button onClick={()=>{
                this.addProduct();
            }} className = 'btn btn-primary me-2'>Add Product</button>
            <button className = 'btn btn-secondary'>Clear All</button>
        </div>
      </>
    );
  }
}
*/