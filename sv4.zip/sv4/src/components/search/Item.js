import React from 'react'
import { AddtoCart } from './AddToCart';

export const Item=(props)=> {

    const style = {
        width:'100px',
        height:'100px'
    };
    return (
        <>
        <div>

            <img alt='Loading...' style = {style} src = {props.product.url}/>
            <p>{props.product.name}</p>
            <p>{props.product.price}</p>

        </div>
        <AddtoCart/>

        </>
    )
}
