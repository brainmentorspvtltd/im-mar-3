import React from 'react'

export const Input=(props)=> {


    return (
        <>
            <label>Search</label>
            <input type='text' placeholder='Type To Search' className='form-control'/>
            <button className='btn btn-primary'>Search</button>
        </>
    )
}
