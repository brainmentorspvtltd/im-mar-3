import {CONFIG} from './config';
import axios from 'axios';
export function loadAxiosConfig(){
    // global
   // axios.defaults.baseURL = 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master';
   console.log('ENV IS ',process.env.REACT_APP_BASE_URL);
   axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
   axios.defaults.timeout = 5000;
}
export function getProducts(){
   // local setting
    // var heavy =  axios.create({
    //     baseURL:'',
    //     timeout:7000
    // });
   // heavy.get()
    const promise = axios.get(CONFIG.PRODUCTS_URL);
    //const promise = fetch(CONFIG.PRODUCTS_URL);
    return promise;
}