import ReactDOM from 'react-dom';
import App from './App';
import { loadAxiosConfig } from './utils/ajax';
import dotenv from 'dotenv';
import { BrowserRouter } from 'react-router-dom';
dotenv.config();
loadAxiosConfig();
ReactDOM.render(<BrowserRouter><App/></BrowserRouter>, document.querySelector('#root'));