import React from 'react';
export const Input = ({name, input})=>{

    let placeHolder = `Type ${name} Here`;

    return (
        <div>
        <label>
            {name}
        </label>
        <input type='text' onChange={(event)=>{
            if(name.startsWith('First')){
            input(event, 'firstname');
            }
            else{
                input(event, 'lastname');
            }
        }} className='form-control' placeholder={placeHolder}/>
        </div>
    )
}