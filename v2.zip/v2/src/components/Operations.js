import React from 'react';
export const Operations = (props)=>{
    return (<button onClick={props.call} className={props.classname}>{props.title}</button>)
}