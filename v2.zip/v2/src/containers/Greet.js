import React from 'react';
import { Input } from '../components/Input';
import { Operations } from '../components/Operations';
import { Output } from '../components/Output';
import { Title } from '../components/Title';
import { CONFIG } from '../utils/config';

export class Greet extends React.Component{
    constructor(){
        super();
        this.names = {};
        this.errors = null;
        this.state = {msg:'', errors: this.errors};
    }
    takeInput (event, name){
        //console.log('This is ',this);
        this.names[name] = event.target.value;
        console.log(this.names);
        //this.firstName = event.target.value;
        //console.log('Take Input Call ',event.target.value );
    }

    initCap(str){
        return str.charAt(0).toUpperCase() + str.substring(1).toLowerCase();
    }

    validate(){
        this.errors = {};
            if(!this.names['firstname']){
                this.errors['firstnameerror'] ='First Name is Blank';
            }
            if(!this.names['lastname']){
                this.errors['lastnameerror'] ='Last Name is Blank';
            }
            this.setState({msg:'',errors:this.errors});
    }

    sayWelcome(){
        if(this.names['firstname'] && this.names['lastname']){
        let message = `Welcome ${this.initCap(this.names['firstname'])} ${this.initCap(this.names['lastname'])} `;
        console.log(message);
        this.errors = null;
        this.setState({msg:message, errors:this.errors});
        }
        else{
            this.validate();
        }
    }

    clearAll(){

    }

    render(){
        return (
            <div className='container'>
                <Title title = {CONFIG.TITLE}/>
                <Input input={this.takeInput.bind(this)} name='First Name'  />
                <span className = 'alert-danger'>{this.errors && this.errors.firstnameerror?this.errors.firstnameerror:''}</span>
                <Input input = {this.takeInput.bind(this)} name = 'Last Name'/>
                <span className = 'alert-danger'>{this.errors && this.errors.lastnameerror?this.errors.lastnameerror:''}</span>
                <br/>
                <Operations call={this.sayWelcome.bind(this)} title = 'Greet' classname='btn btn-primary me-3'/>
                <Operations call={this.clearAll.bind(this)} title = 'Clear All' classname = 'btn btn-secondary'/>
                <Output result = {this.state.msg}/>
            </div>
        );
    }
}