import  {createContext} from 'react';
export const ShareContext = createContext({totalItemsInCart:0,
     updateTotal:()=>{}});