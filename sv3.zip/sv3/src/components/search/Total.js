import React from 'react'

export const Total=(props)=> {


    return (
        <>
            <p>Total Amount is  </p>
        </>
    )
}
