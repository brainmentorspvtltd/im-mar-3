import React from 'react';
import { ShareContext } from '../../models/sharecontext';
export const ViewItemsInCart = React.memo((props)=>{
    console.log('Re Render of ViewItemsInCart');
    return (
    <ShareContext.Consumer>
        {
            (shareContext)=>{
                return (<div className = 'text-end'>Items in Cart {shareContext.totalItemsInCart}</div>)
            }
        }


    </ShareContext.Consumer>
    )
});