import React, { useState } from 'react'
import { ShareContext } from '../../models/sharecontext';

export const AddtoCart=(props)=> {
    console.log('AddToCart Re-Render');
    const [toggle, setToggle] = useState(false);
    const [like, setLike] = useState(0);
    const toggleIt=()=>{
        setToggle(!toggle);
    }
    const likeIt = ()=>{
        setLike(like+1);
    }
    return (
        <>
            <ShareContext.Consumer>
                {
                    (shareContext)=>{
                        return (
                            <button onClick={()=>{
                                let val = !toggle?1:-1;
                                shareContext.updateTotal(val);
                                toggleIt();

                            }} className = 'btn btn-success'>{toggle?'Remove From Cart':'Add to Cart'}</button>
                        )
                    }
                }
            </ShareContext.Consumer>

            <button onClick={likeIt}>Likes</button>
            <p>Likes are {like}</p>
            <br/>
        </>
    )
}
