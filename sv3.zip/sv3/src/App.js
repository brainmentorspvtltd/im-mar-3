import React, {useState} from 'react';
import Search from './containers/Search';
import { ShareContext } from './models/sharecontext';

//let total  = 0;
const App= (props)=> {
    console.log('Re Render of App');

    const [total, setTotal] = useState(0);
    const updateTotalFn = (currentValue)=>{
       // total += currentValue;
        console.log('Total is ',total);
        setTotal(total + currentValue);
    }

    return (
        <>
            <ShareContext.Provider value={{totalItemsInCart: total, updateTotal: updateTotalFn}}>
            <Search/>
            </ShareContext.Provider>
        </>
    )
}
export default App;
