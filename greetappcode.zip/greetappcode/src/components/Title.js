import React from 'react';
export const Title = (props)=>{
    return ( <h1 className='alert-success text-center'>{props.title}</h1>);
}