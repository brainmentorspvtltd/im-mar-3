import React from 'react';
export const Operations = (props)=>{
    return (<button className={props.classname}>{props.title}</button>)
}