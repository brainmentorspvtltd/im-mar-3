import React from "react";
export const Output = () => {
  // <React.Fragment>
  // </React.Fragment>);
  return (
    <>
      <hr />
      <p></p>
    </>
  );
};
