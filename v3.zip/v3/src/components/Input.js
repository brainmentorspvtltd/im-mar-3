import React from 'react';
export const Input = ({name, input, val})=>{

    let placeHolder = `Type ${name} Here`;

    return (
        <div>
        <label>
            {name}
        </label>
        <input type='text' value={val} onChange={(event)=>{
            if(name.startsWith('First')){
            input(event, 'firstname');
            }
            else{
                input(event, 'lastname');
            }
        }} className='form-control' placeholder={placeHolder}/>
        </div>
    )
}