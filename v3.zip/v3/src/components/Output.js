import React from "react";
export const Output = ({result}) => {
  // <React.Fragment>
  // </React.Fragment>);
  return (
    <>
      <hr />
      <p>{result}</p>
    </>
  );
};
