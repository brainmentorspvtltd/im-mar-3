export const CONFIG = {
    TITLE:'GREET - APP '
}