const http = require('http');
//const https = require('https');
const fs = require('fs');
const path = require('path');
const productOperations = require('./db/productOperations');
const fileOperations = require('./utils/fileserve');
const dotenv = require('dotenv');
const parsePost = require('./utils/parser');
dotenv.config();
const cors = require('./utils/cors');

const certOptions = {
    key: fs.readFileSync(path.join(__dirname,'/cert/privatekey.key')),
    cert: fs.readFileSync(path.join(__dirname,'/cert/certificate.pem'))
};
//cors();
//const server = https.createServer(certOptions, (request, response)=>{
const server = http.createServer((request, response)=>{
    //console.log(request);
    //cors(response);

    //response.setHeader('content-type','application/json');
    const method = request.method;
    const headers = cors();

    response.writeHead(200, headers);

const url = request.url=='/'?'/index.html':request.url;

if (method === "OPTIONS") {
    const NO_CONTENT = 204;
    response.writeHead(NO_CONTENT, headers);
    response.end();
    return;
  }

console.log(url , method);
    //const url = request.url;
    console.log('URL ', url);
    if(fileOperations.isStaticFile(url)){
        fileOperations.serveFile(response, url);
    }
    else
    if(url=='/addproduct' &&  method == 'POST'){
        console.log('....Add Product ........ Server');
        const requestPromise = parsePost(request);
        requestPromise.then(productObject=>{

            const promise = productOperations.addProduct(productObject);
            promise.then(data=>{
                response.write(JSON.stringify({message:'Product Added '}));

               // console.log('Added ',data);
            }).catch(err=>{
                response.write(JSON.stringify({message:'Product Not Added '}));
                console.log(err);
            }).finally(()=>{
                response.end();
            })

        }).catch(err=>{

        })


    }
    else
    if(url==='/mobiles' && method ==='GET'){
        const promise = productOperations.getProducts();
            promise.then(data=>{
                response.write(JSON.stringify({mobiles:data}));

               // console.log('Added ',data);
            }).catch(err=>{
                response.write(JSON.stringify({message:'Error in Getting Product '}));
                console.log(err);
            }).finally(()=>{
                response.end();
            })
    }

    // response.write('Hello I am Https Server');
    // response.end();
});
server.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log('Server Start Error ',err);
    }
    else{
        console.log('Server Started... ', server.address().port);
    }
})