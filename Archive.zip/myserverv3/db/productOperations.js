const dbConnect = require('./connect');
const productOperations = {
    addProduct(product){
        let connection = dbConnect();
        const SQL = 'insert into products SET ?';
        const promise= new Promise((resolve , reject)=>{
            connection.query(SQL, product,(err, result)=>{
                if(err){
                    reject(err);
                }
                else{
                    console.log('Added ', product);
                    resolve(result);
                }
            });
        });
        return promise;

    },

    getProducts(){
        let connection = dbConnect();
        const SQL = 'select * from  products ';
        const promise= new Promise((resolve , reject)=>{
            connection.query(SQL,(err, result)=>{
                if(err){
                    reject(err);
                }
                else{
                    console.log('Get Products ', result);
                    resolve(result);
                }
            });
        });
        return promise;
    }
}

module.exports = productOperations;
