module.exports = (request)=>{
    let allData = '';
    const promise = new Promise((resolve, reject)=>{
        request.on('data',chunk=>{
            allData += chunk;
            console.log('Data is ',chunk);
        })
        request.on('end',()=>{
            console.log('JSON Rec ', allData);
            resolve(JSON.parse(allData));
        });
        request.on('error', err=>{
            reject(err);
        });
    });
    return promise;

}