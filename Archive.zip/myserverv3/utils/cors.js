module.exports = ()=>{

    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS, POST, GET",
        "Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept, Authorization",
        "Access-Control-Max-Age": 2592000, // 30 days
        /** add other headers as per requirement */
      };
      return headers;
    //response.writeHead(200, headers);
//     response.setHeader("Access-Control-Allow-Origin", "*");
//    response.setHeader('Access-Control-Allow-Methods', '*');
//    response.setHeader("Access-Control-Allow-Headers", "*");
}