import React from 'react'
import {connect} from 'react-redux';
import {NoRecordFound} from '../components/widgets/NoRecordFound';
import {List} from '../components/search/List';
const Home=(props)=> {
    console.log('Home Render Call.....');

    return (
        <>
              <h1>Recently Added Products</h1>
              Products Are ::: {props.addedproducts.length}
              {props.addedproducts.length===0?<NoRecordFound/>:<List products = {props.addedproducts}/>}

        </>
    )
}
const mapStateToProps = (state)=>{
    return {
        'addedproducts':state.newproducts
    }
}
// const fn = connect(mapStateToProps);
// fn(Home);
export default connect(mapStateToProps)(Home);
