import React from 'react'
import loading from '../assets/loading.gif';

export const About=(props)=> {

    const movetoHome=()=>{
            props.history.push('/');
    }
    return (
        <>
                <h1>I am About {props.match.params.name} {props.match.params.city}</h1>
                <button onClick= {movetoHome}>Home Page</button>
                <img src={loading}/>
         </>
    )
}
