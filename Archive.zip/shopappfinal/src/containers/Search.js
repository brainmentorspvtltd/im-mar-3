import React, { Component, PureComponent } from 'react'
import { Input } from '../components/search/Input';
import { List } from '../components/search/List';
import { TotalItems } from '../components/search/TotalItems';
import { Total } from '../components/search/Total';
import { Title } from '../components/widgets/Title';
import { getProducts } from '../utils/ajax';
import { ViewItemsInCart } from '../components/search/ViewItemsInCart';
import { ShareContext } from '../models/sharecontext';
import { NoRecordFound } from '../components/widgets/NoRecordFound';
import { AddProduct } from '../components/AddProduct';

export default class Search extends PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            products:[]
        };
        console.log("1. Constructor Call");


    }

    UNSAFE_componentWillMount(){
        console.log("2. ComponentWillMount Call");
    }

   /* shouldComponentUpdate(nextProps, nextState){
        // if(this.props.x<nextProps.x){
        //     return true;
        // }
        // else{
        //     return false;
        // }
        return true;
        /*if(this.props != nextProps && this.state != nextState){
            return true;
        }
        else{
            return false;
        }*/
    //}*/

    render() {
        console.log("3. Search Render Call");
        return (
            <div className = 'container'>
                {/* <ShareContext.Consumer>
                    {()=>{

                    }}
                </ShareContext.Consumer> */}

                <Title/>
                <ViewItemsInCart/>
                <Input/>
                <TotalItems total = {this.state.products.length}/>
                {this.state.products.length===0?<NoRecordFound/>:<List products = {this.state.products}/>}

                <Total/>
            </div>
        )
    }

    componentDidMount(){
        console.log("4. ComponentDidMount Call ");
        setTimeout(()=>{
            const promise = getProducts();
        promise.then(response=>{
            //console.log(response.data.products);
            this.setState({products:response.data.mobiles});
        }).catch(err=>{
            console.log('Error is ',err);
        })
        },1000);

        // promise.then(response=>{
        //     response.json().then(data=>{
        //         console.log('Data Rec ',data);
        //         this.setState({products:data.products});
        //     }).catch(err=>{
        //         console.log('Invalid JSON ',err);
        //     })
        // }).catch(err=>{
        //     console.log('Response Error ',err);
        // })
    }



}
