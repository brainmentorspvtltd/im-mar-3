import {CONFIG} from './config';
import axios from 'axios';
export function loadAxiosConfig(){
    // global
   // axios.defaults.baseURL = 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master';
   console.log('ENV IS ',process.env.REACT_APP_BASE_URL);
   axios.defaults.baseURL = process.env.REACT_APP_BASE_URL;
   axios.defaults.timeout = 10000;
//    let myInterceptor = axios.interceptors.request.use(requestObject=>{
//        console.log('$$$$$$$$Interceptor Call...........');
//     requestObject.tokenId = localStorage.tokenId;
//     // cancel
//    // requestObject.cancel();
//     return requestObject;
//    },err=>{
//        console.log('Error in Request Interceptor ',err);
//    });
//    setTimeout(()=>{
//     axios.interceptors.request.eject(myInterceptor);
//     console.log('Eject Interceptor....');
//    },10000);

}
export function addProductToDatabase(product){
    console.log(' addProductToDatabase Product is ',product);
   //const promise =axios.post(CONFIG.ADD_PRODUCT_URL,{id:1888,name:'AAA',price:88888,url:'gdfgfjghkd'});
  // const promise = axios.post('http://localhost:7979/addproduct',product);

  const promise =  axios.post(CONFIG.ADD_PRODUCT_URL, product, {
    'Content-Type':'application/json'
  });
  // const promise = axios.post('http://localhost:7979/addproduct',product,{
    //     headers:{
    //             'Content-Type':'application/json'

    //     }
    // });
    // const promise = fetch('http://localhost:7979/addproduct', {
    //     method:'POST',
    //     body:JSON.stringify(product),
    //     headers:{'Content-Type':'application/json'}

    // })
    return promise;
}
export function getProducts(){
   // local setting
    // var heavy =  axios.create({
    //     baseURL:'',
    //     timeout:7000
    // });
   // heavy.get()
    const promise = axios.get(CONFIG.PRODUCTS_URL);
    //const promise = fetch(CONFIG.PRODUCTS_URL);
    return promise;
}