export const CONFIG = {
    //PRODUCTS_URL :'http://localhost:3000/server/products.json'
    //PRODUCTS_URL:'/mobiles.json',
    PRODUCTS_URL:'/mobiles',
    ADD_PRODUCT:'ADD_PRODUCT',
    ADD_PRODUCT_URL : '/addproduct'

}