import { CONFIG } from "../utils/config";

const newProducts = {'newproducts':[]};
export const productReducer = (state = newProducts, action)=>{
    if(action.type===CONFIG.ADD_PRODUCT){
        let products = state.newproducts;
        products.push(action.payload);
        return {...state,'newproducts':products};
    }
    return state; // State Update
}