const adder = require('./one');
console.log(typeof adder);
console.log(adder(100,200));
const three = require('./three');
console.log(typeof three);
console.log(three.add(10000,20000));
console.log(three.subtract(10,20));