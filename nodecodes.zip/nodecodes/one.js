module.exports = function add(x=0,y=0){
//     var x = 100;
// var y = 200;
var z = x + y;
//console.log('Hello Node JS ',z);
return z;
}

