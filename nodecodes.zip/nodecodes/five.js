process.on('uncaughtException',(err)=>{
    console.log('Caught It ',err);
    // Mail
})

process.on('exit',()=>{
    console.log('Exit ');
    // TimeStamp
})
process.exit();
console.log(process.versions.node);
console.log(process.versions.v8);
console.log(process.versions.uv);
console.log(process.arch);
console.log(process.platform);
console.log(process.cpuUsage());
console.log(process.argv[2]);
fun2();
const mode = process.argv[2];
if(mode == 'DEV'){
    // Application DEV Mode
    // Local Env Read
}
else
if(mode=='PROD'){
    // Application PROD Mode
    // Cloud Env Read

}