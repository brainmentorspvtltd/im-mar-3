// module.exports = {
//      add(x,y){
//         return x + y;
//     },
//      sub(x,y){
//         return x - y;
//     }
// }

const calc = {
    add(x,y){
       return x + y;
   },
    sub(x,y){
       return x - y;
   }
}
module.exports = calc;