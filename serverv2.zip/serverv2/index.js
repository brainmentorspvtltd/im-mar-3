//const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const productOperations = require('./db/productOperations');
const fileOperations = require('./utils/fileserve');
const dotenv = require('dotenv');
dotenv.config();
const certOptions = {
    key: fs.readFileSync(path.join(__dirname,'/cert/privatekey.key')),
    cert: fs.readFileSync(path.join(__dirname,'/cert/certificate.pem'))
};
const server = https.createServer(certOptions, (request, response)=>{
    const url = request.url=='/'?'/index.html':request.url;
    //const url = request.url;
    console.log('URL ', url);
    if(fileOperations.isStaticFile(url)){
        fileOperations.serveFile(response, url);
    }
    else
    if(url=='/addproduct'){
        const promise = productOperations.addProduct({id:1002, name:'Samsung IPhone ',price:19999, url:'https://pngimg.com/uploads/iphone_12/iphone_12_PNG36.png'})
promise.then(data=>{
    response.write(JSON.stringify({message:'Product Added '}));

   // console.log('Added ',data);
}).catch(err=>{
    response.write(JSON.stringify({message:'Product Not Added '}));
    console.log(err);
}).finally(()=>{
    response.end();
})

    }

    // response.write('Hello I am Https Server');
    // response.end();
});
server.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log('Server Start Error ',err);
    }
    else{
        console.log('Server Started... ', server.address().port);
    }
})