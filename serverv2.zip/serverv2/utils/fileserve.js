const fs = require('fs');
const path = require('path');
module.exports = {

    isStaticFile(fileName){
        const extensions = ['.html','.css','.js','.png','.jpg','.jpeg'];
        return extensions.indexOf(path.extname(fileName))>=0;
    },

    serveFile(response, url){
        const parent = path.normalize(__dirname+'/..');
        const fullPath = path.join(parent, '/public',url);
        const readStream = fs.createReadStream(fullPath);
        readStream.pipe(response);

    }

}
