const dbConnect = require('./connect');
const productOperations = {
    addProduct(product){
        let connection = dbConnect();
        const SQL = 'insert into products SET ?';
        const promise= new Promise((resolve , reject)=>{
            connection.query(SQL, product,(err, result)=>{
                if(err){
                    reject(err);
                }
                else{
                    resolve(result);
                }
            });
        });
        return promise;

    }
}

module.exports = productOperations;
