const mysql = require('mysql');

module.exports = function dbConnect(){
    console.log(process.env.DB_URL);
    console.log(process.env.USERID);
    console.log(process.env.PASSWORD);
    console.log(process.env.DB_NAME);
    const connection = mysql.createConnection({
        host:process.env.DB_URL,
        user:process.env.USERID,
        password:process.env.PASSWORD,
        database:process.env.DB_NAME
    });
    connection.connect((err)=>{
        if(err){
            console.log('DB Connection Error ',err);
            throw err;
        }
        else{
            console.log('Connection Created...');
        }
    })
    return connection;
}